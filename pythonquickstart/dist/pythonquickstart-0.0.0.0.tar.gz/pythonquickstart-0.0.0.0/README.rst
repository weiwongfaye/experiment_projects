pythonquickstart
=================

Installation
-------------

``sh
        python setup.py clean build install
``

Licence
--------


Contribute
------------