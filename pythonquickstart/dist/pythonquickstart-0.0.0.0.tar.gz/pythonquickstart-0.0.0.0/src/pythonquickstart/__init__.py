""" pythonquickstart/__init__.py """
# -*- coding: utf-8 -*

__all__ = []

from .pythonquickstart import *