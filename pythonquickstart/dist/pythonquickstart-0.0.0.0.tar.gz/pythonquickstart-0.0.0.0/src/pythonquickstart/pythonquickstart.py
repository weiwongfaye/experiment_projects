#!/usr/bin/env python2
""" pythonquickstart """
# -*- coding: utf-8 -*